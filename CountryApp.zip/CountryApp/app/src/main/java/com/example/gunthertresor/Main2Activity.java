package com.example.gunthertresor;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        TextView textView = (TextView)findViewById(R.id.textView);
        TextView countryinfoView = (TextView)findViewById(R.id.countryinfo);

        textView.setText(getIntent().getStringExtra("Country"));
        imageView.setImageResource(getIntent().getIntExtra("Flag", R.drawable.india));
        countryinfoView.setText(getIntent().getStringExtra("countryinfo"));
        /**Intent intent = getIntent();
        String value = intent.getStringExtra("value");

        if(value == "india"){
            imageView.setImageResource(getIntent().getIntExtra("Flag", R.drawable.india));
            textView.setText("welcome to india");
        }
        else if (value == "ireland"){
            imageView.setImageResource(getIntent().getIntExtra("Flag", R.drawable.ireland));
            textView.setText("welcome to ireland");
         switch(position)
        {
            case 0:

                Intent myIntent = new Intent(MainActivity.this, Main3Activity.class);
                startActivityForResult(myIntent, 0);

                break;

            case 1:

                Intent Intent = new Intent(MainActivity.this, Main4Activity.class);
                startActivityForResult(Intent, 0);
        }*/


        }
    }

