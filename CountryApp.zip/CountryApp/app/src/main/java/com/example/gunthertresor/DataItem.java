package com.example.gunthertresor;



public class DataItem {
    int resIdThumbnail;
    String countryName;
    String countryinfo;

    public DataItem(int resIdThumbnail, String countryName, String countryinfo) {
        this.resIdThumbnail = resIdThumbnail;
        this.countryName = countryName;
        this.countryinfo = countryinfo;
    }
}
