package com.example.gunthertresor;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    public TextView startTimeField,endTimeField;
    private MediaPlayer mediaPlayer;
    private double startTime = 0;
    private double finalTime = 0;
    private Handler myHandler = new Handler();
    private int forwardTime = 5000;
    private int backwardTime = 5000;
    private SeekBar seekbar;
    private ImageButton playButton,pauseButton;
    public static int oneTimeOnly = 0;
    String songName;

    List<DataItem> lstData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startTimeField =(TextView)findViewById(R.id.textView1);
        endTimeField =(TextView)findViewById(R.id.textView2);
        seekbar = (SeekBar)findViewById(R.id.seekBar1);
        playButton = (ImageButton)findViewById(R.id.imageButton1);
        pauseButton = (ImageButton)findViewById(R.id.imageButton2);
        songName = "playing: fifasong2018";
        mediaPlayer = MediaPlayer.create(this, R.raw.fifasong2018);
        pauseButton.setEnabled(false);


        lstData = new ArrayList<>();

        lstData.add(new DataItem(R.drawable.india,"India", "India has never participated in the FIFA World Cup. "));
        lstData.add(new DataItem(R.drawable.ireland,"IreLand","The Republic of " +
                "Ireland have appeared in the finals of the FIFA World Cup on three occasions, in 1990, 1994 and 2002. "));
        lstData.add(new DataItem(R.drawable.uk,"UK","England are one of the two" +
                " oldest national teams in football,they played in the world's first international football match in 1872,15 appearances at the world cup.Also qualified for 2018."));

        lstData.add(new DataItem(R.drawable.usa,"USA", "The team has appeared in ten FIFA World Cups, " +
                "including the first in 1930, where they reached the semi-finals.10 appearances at the world cup."));
        lstData.add(new DataItem(R.drawable.japan,"Japan" ,"Japan have appeared in the finals of the FIFA" +
                " World Cup on five occasions, the first being in 1998 where they lost all three group games and finished in 31st position.6 appearances.Also qualified for 2018."));
        lstData.add(new DataItem(R.drawable.germany,"Germany", "Germany is one of the most successful national teams " +
                "in international competitions, having won a total of four World Cups (1954, 1974, 1990, 2014), " +
                "three European Championships (1972, 1980, 1996), and one Confederations Cup (2017). They have " +
                "also been runners-up three times in the European Championships, four times in the World Cup, and a " +
                "further four third-place finishes at World Cups. East Germany won Olympic Gold in 1976. 19 appearances at the world cup.Also qualified for 2018."));
        lstData.add(new DataItem(R.drawable.france,"France" , "France was one of the four European teams that participated at the " +
                "inaugural World Cup in 1930 and have appeared in 14 FIFA World Cups,The French team won its first " +
                "and only World Cup title in 1998.Also qualified for 2018."));
        lstData.add(new DataItem(R.drawable.spain,"Spain", "Spain is one of only eight countries ever to have won the FIFA World Cup, " +
                "which it did at the 2010 FIFA World Cup, in South Africa, the first time the team had reached the final. The team is one of the most present at the World Cup finals, " +
                "with 14 appearances out of the 20 tournaments.Also qualified for 2018."));
        lstData.add(new DataItem(R.drawable.italy,"Italy", "Italy is one of the most successful national teams in the history of the World Cup, " +
                "having won four titles (1934, 1938, 1982, 2006), just one fewer than Brazil. The team was present in 18 out of the 21 tournaments, " +
                "reaching six finals, a third place and a fourth place."));
        lstData.add(new DataItem(R.drawable.china,"China","China failed to score a goal in their maiden World Cup appearance in 2002. However, " +
                "qualifying for the tournament has been considered the greatest accomplishment in China's football history."));
        lstData.add(new DataItem(R.drawable.brazil,"Brazil","Brazil is the most successful national team in the history of the World Cup, having won five titles, earning second-place, " +
                "third-place and fourth-place finishes twice each. Brazil is one of the countries besides Argentina, Spain and Germany to win a FIFA World Cup away from its continent (Sweden 1958, Mexico 1970, USA 1994 and South Korea/Japan 2002). " +
                "Brazil is the only national team to have played in all FIFA World Cup editions without any absence or need for playoffs. " +
                "Brazil also has the best overall performance in World Cup history in both proportional and absolute terms with a record of 70 victories in 104 matches played, 119 goal difference, " +
                "227 points and only 17 losses.Also qualified for 2018."));
        lstData.add(new DataItem(R.drawable.canada,"Canada","Their most significant achievements are winning the 1985 CONCACAF Championship to qualify " +
                "for the 1986 FIFA World Cup[2] and winning the 2000 CONCACAF Gold Cup to qualify for the 2001 FIFA Confederations Cup. 1 appearance at the world cup so far."));
        lstData.add(new DataItem(R.drawable.hongkong,"HongKong","No world cup record"));
        lstData.add(new DataItem(R.drawable.korea,"Korea","South Korea have appeared in the FIFA World Cup on nine occasions in 1954 and 1986 to 2014. " +
                "Their best ever performance is a fourth place in the 2002 tournament co-hosted at home soil and at Japan. Also qualified in 2018."));
        lstData.add(new DataItem(R.drawable.sweden,"Sweden","Sweden have been one of the more successful national teams in the history of the World Cup, having reached 4 semi-finals, " +
                "and becoming runners-up on home ground in 1958. They have been present at 11 out of 20 World Cups by 2014. " +
                "They will make their twelfth appearance at the finals in the 2018 FIFA World Cup in Russia."));


        ListView listView = (ListView)findViewById(R.id.listView);

        CustomAdapter adapter = new CustomAdapter(this,R.layout.itemrow,lstData);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent();
                intent.putExtra("Country", lstData.get(position).countryName);
                intent.putExtra("Flag", lstData.get(position).resIdThumbnail);
                intent.putExtra("countryinfo", lstData.get(position).countryinfo);

                intent.setClass(MainActivity.this,Main2Activity.class);
                startActivity(intent);

            }
        });
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

        builder.setCancelable(true);

        builder.setTitle("Welcome!!");
        builder.setMessage("Thanks for using our APP.");
        /*


          Setting Negative "Cancel" Button
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                dialog.cancel();
            }
        });

         Setting Positive "Yes" Button
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

            }
        });*/

        builder.show();
        //AlertDialog dialog = builder.create();

        // Finally, display the alert dialog
        //dialog.show();

        //dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.YELLOW));



    }
    public void play(View view){
        Toast.makeText(getApplicationContext(),songName,Toast.LENGTH_SHORT).show();
        mediaPlayer.start();
        finalTime = mediaPlayer.getDuration(); startTime = mediaPlayer.getCurrentPosition();
        if(oneTimeOnly == 0){
            seekbar.setMax((int) finalTime);
            oneTimeOnly = 1;
        }
        endTimeField.setText(String.format("%d min, %d sec",
                TimeUnit.MILLISECONDS.toMinutes((long) finalTime),
                TimeUnit.MILLISECONDS.toSeconds((long) finalTime) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS. toMinutes((long) finalTime)))
        );
        startTimeField.setText(String.format("%d min, %d sec",
                TimeUnit.MILLISECONDS.toMinutes((long) startTime),
                TimeUnit.MILLISECONDS.toSeconds((long) startTime) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS. toMinutes((long) startTime)))
        );
        seekbar.setProgress((int)startTime);myHandler.postDelayed(UpdateSongTime,100);
        pauseButton.setEnabled(true);
        playButton.setEnabled(false);

    }
    private Runnable UpdateSongTime = new Runnable() {
        public void run() {
        startTime = mediaPlayer.getCurrentPosition();
        startTimeField.setText(String.format("%d min, %d sec",
                TimeUnit.MILLISECONDS.toMinutes((long) startTime),
                TimeUnit.MILLISECONDS.toSeconds((long) startTime) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) startTime)))
        );
        seekbar.setProgress((int)startTime);
        myHandler.postDelayed(this, 100);
    }
    };
    public void pause(View view){
        Toast.makeText(getApplicationContext(), "Pausing sound", Toast.LENGTH_SHORT).show();
        mediaPlayer.pause();
        pauseButton.setEnabled(false);
        playButton.setEnabled(true);
    }
    public void forward(View view){
        int temp = (int)startTime; if((temp+forwardTime)<=finalTime){
            startTime = startTime + forwardTime;
            mediaPlayer.seekTo((int) startTime); }
        else{ Toast.makeText(getApplicationContext(), "Cannot jump forward 5 seconds", Toast.LENGTH_SHORT).show();
        }
    }
    public void rewind(View view){
        int temp = (int)startTime;
        if((temp-backwardTime)>0){
            startTime = startTime - backwardTime;
            mediaPlayer.seekTo((int) startTime); }
        else{Toast.makeText(getApplicationContext(), "Cannot jump backward 5 seconds", Toast.LENGTH_SHORT).show();
        } }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        return true;
    }
}
